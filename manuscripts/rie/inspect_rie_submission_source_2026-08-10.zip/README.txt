Inspect RiE submission source (frozen 2026-08-10)
SSOT: inspect-gate/manuscripts/rie @ ab8db0f
Contents: paper_rie.tex + paper_rie.bbl + refs.bib + figures/*.pdf
