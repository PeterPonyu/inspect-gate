Inspect RiE submission source (frozen 2026-08-10)
Contents: paper_rie.tex + paper_rie.bbl + refs.bib + figures/*.pdf

Build command:
  latexmk -pdf -interaction=nonstopmode -halt-on-error paper_rie.tex

SHA256SUMS covers every payload member except SHA256SUMS itself.
