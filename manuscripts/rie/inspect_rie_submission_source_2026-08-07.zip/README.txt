Results in Engineering source package
Built from the active RiE manuscript source on 07 August 2026.

Build command:
  latexmk -pdf -interaction=nonstopmode -halt-on-error paper_rie.tex

The compiled manuscript PDF and cover letter are uploaded separately.
This package contains the manuscript source, bibliography, compiled BBL, and exactly 18 referenced figure PDFs. The staged source compiles to 63 pages.
